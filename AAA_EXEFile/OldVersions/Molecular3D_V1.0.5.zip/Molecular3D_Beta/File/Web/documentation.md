# Molecular3D 使用文档

> **分子3D可视化与优化工具** - 基于MMFF94力场的分子构象优化系统，采用SMILES格式进行分子解析

## 📌 功能概述

Molecular3D 是一个集成了2D分子结构绘制与3D构象优化的Web工具，支持：
- 🎨 交互式2D分子结构绘制
- ⚗️ MMFF94力场优化计算
- 🌐 多种3D模型渲染
- 📦 多格式模型导出（PNG/STL/GLB）

---

## 🎨 左侧绘图区

### 原子工具
| 按钮              | 功能         | 快捷操作           |
| ----------------- | ------------ | ------------------ |
| **C, H, O, N, S** | 选择原子类型 | 点击后在画布上绘制 |

### 键工具
- **单键** - 普通单键（可通过点击已有键循环切换）
- **双键** - 双键（点击可切换居中/左偏/右偏样式）
- **三键** - 三键
- **楔形键** - 立体化学表示
  - 🔺 **实楔形键**：指向纸面外
  - 🔻 **虚楔形键**：指向纸面内

### 操作模式
| 模式     | 图标 | 功能         |
| -------- | ---- | ------------ |
| **构造** | ✏️    | 绘制分子结构 |
| **移动** | 🤚    | 拖动原子和键 |
| **套索** | 🔲    | 框选多个元素 |

### 绘制技巧
1. **添加原子**：选择原子类型后，在画布空白处点击
2. **连接原子**：点击已有原子并拖动到另一原子
3. **自动延伸**：从原子拖动到空白处，自动延伸并吸附到标准角度（30°倍数）
4. **修改元素**：选择新原子类型，点击已有原子替换
5. **循环键型**：在**单键**模式下点击已有键，按 `单键 → 双键 → 三键 → 单键` 循环
6. **双键样式**：在**双键**模式下点击双键，按 `居中 → 左偏 → 右偏 → 居中` 循环

### 快捷键
- `Delete` / `Backspace` - 删除选中元素
- `鼠标滚轮`/`键盘上下左右` - 滚动画布

---

## 🧬 右侧3D区

### 模型渲染
#### 球棍模型（Ball & Stick）
- 原子显示为彩色球体（根据元素类型）
- 键显示为灰色棍状连接
- 适合清晰展示原子位置和键连接

#### 棒状模型（Stick）
- 原子和键统一为棍状结构
- 键根据连接的原子颜色分段显示
- 适合观察整体骨架结构

### 光照调节
| 参数           | 范围      | 效果               |
| -------------- | --------- | ------------------ |
| **环境光强度** | 0.0 - 5.0 | 整体亮度           |
| **平行光强度** | 0.0 - 2.0 | 立体感（阴影效果） |

**预设方案**：
- 🌤️ **清透** - 高环境光（4.0）+ 低平行光（0.1）
- 🌓 **立体** - 中环境光（2.5）+ 高平行光（0.8）

### 参数修改
- **背景颜色** - 支持自定义颜色或快速选择黑/灰/白
- **显示氢原子** - 切换是否显示氢原子

### 导出功能
| 格式        | 用途       | 特性                   |
| ----------- | ---------- | ---------------------- |
| **PNG图片** | 文档/演示  | 透明背景，适合嵌入文档 |
| **STL模型** | 3D打印     | 标准3D打印格式         |
| **GLB模型** | PowerPoint | 可直接插入PPT的3D模型  |

---

## ⌨️ 3D视图交互

| 操作             | 功能             |
| ---------------- | ---------------- |
| **鼠标中键拖动** | 旋转视图         |
| **鼠标左键拖动** | 平移视图         |
| **鼠标滚轮**     | 缩放视图         |
| **点击原子**     | 显示原子详细信息 |
| **再次点击**     | 取消高亮         |

---

## 🔄 完整工作流程

1. **绘制2D结构**
   - 在左侧画布使用工具绘制分子骨架
   - 添加必要的立体化学信息（楔形键）

2. **3D构象优化**
   - 点击中间的**3D构象优化**按钮
   - 等待C++服务器计算（MMFF94力场优化）
   - 自动加载优化后的3D结构

3. **调整显示效果**
   - 切换球棍/棒状模型
   - 调整光照参数
   - 修改背景颜色

4. **导出结果**
   - 根据需求选择导出格式
   - PNG用于文档
   - STL用于3D打印
   - GLB用于PPT嵌入

---

## 🐛 常见问题

### Q: 点击"3D构象优化"后显示"未连接"？
**A:** 请确保：
1. `Main_MMFF94.exe` 正在运行
2. 控制台显示"Socket服务器已启动"
3. 端口8765未被占用
4. 防火墙允许本地连接

### Q: 转换超时怎么办？
**A:** 大型分子计算耗时较长，请耐心等待。如果超过10分钟：
- 检查C++程序是否崩溃
- 尝试简化分子结构
- 重启C++服务器

### Q: 导出的GLB模型在PowerPoint中颜色很暗？
**A:** 已自动增强颜色饱和度和亮度。如仍不满意，可在PPT中：
1. 选中3D模型
2. 右键 → 3D模型 → 格式
3. 调整光照和材质

### Q: 画布超出屏幕范围？
**A:** 使用滚动条或调整浏览器窗口大小，画布会自动适应

### Q: 如何清空画布？
**A:** 使用**套索**模式框选所有元素，然后按 `Delete` 删除

---

## 💡 高级技巧

### 快速绘制苯环
1. 绘制第一个碳原子
2. 以 60° 间隔依次延伸 6 个碳原子
3. 连接首尾形成环
4. 交替设置单键和双键

### 立体化学标注

> [!Warning]
>
> 仅支持绘制，目前解析中楔形键按单键处理。

- **S构型**：使用虚楔形键标记向后的取代基
- **R构型**：使用实楔形键标记向前的取代基

### 批量操作
1. 使用**套索**模式框选多个原子
2. 在**移动**模式下拖动整体移动
3. 按 `Delete` 删除选中部分

---

## 📚 技术说明

- **格式解析**：SMILES & Canonical SMILES[^1][^2]
- **力场算法**：MMFF94（Merck Molecular Force Field）[^3][^4][^5][^6][^7]
- **优化方法**：旋转角及键角迭代调整（详见论文）
- **渲染引擎**：Three.js (WebGL)
- **前端框架**：原生JavaScript + SVG
- **后端通信**：HTTP REST API (本地8765端口)
- **后端计算**：C++14

---

## 🔗 项目信息

- **GitHub仓库**: [stellalinsmail-dotcom/Molecular_3D](https://github.com/stellalinsmail-dotcom/Molecular_3D)
- **开源协议**: MIT License
- **版本**: v1.0.0
- **更新日期**: 2025年11月9日
- **论文信息**: 如果论文能够上知网再说吧。。

---

**感谢使用 Molecular3D！** 🎉  

如有问题或建议，欢迎在 [GitHub Issues](https://github.com/stellalinsmail-dotcom/Molecular_3D/issues) 提出。

## 📑 参考文献

[^1]:Weininger D. SMILES, a chemical language and information system. 1. Introduction to methodology and encoding rules[J]. Journal of Chemical Information and Computer Sciences, 1988, 28(1): 31-36. DOI: 10.1021/ci00062a008
[^2]:Weininger D, Weininger A, Weininger J L. SMILES. 2. Algorithm for generation of unique SMILES notation[J]. Journal of Chemical Information and Computer Sciences, 1989, 29(2): 97-101. DOI: 10.1021/ci00057a005
[^3]:Halgren T A. Merck molecular force field. I. Basis, form, scope, parameterization, and performance of MMFF94[J]. J. Comput. Chem., 1996, 17: 490-519.
[^4]:Halgren T A. Merck molecular force field. II. MMFF94 van der Waals and electrostatic parameters for intermolecular interactions[J]. J. Comput. Chem., 1996, 17(5/6): 520-552. DOI:10.1002/(SICI)1096-987X(199604)17:5/6<520::AID-JCC2>3.0.CO;2-W.
[^5]: Halgren T A. Merck molecular force field. III. Molecular geometries and vibrational frequencies for MMFF94[J]. J. Comput. Chem., 1996, 17(5/6): 553-586. DOI:10.1002/(SICI)1096-987X(199604)17:5/6<553::AID-JCC3>3.0.CO;2-T
[^6]:  Halgren T A, Nachbar R B. Merck molecular force field. IV. Conformational energies and geometries for MMFF94[J]. J. Comput. Chem., 1996, 17(5/6): 587-615. DOI:10.1002/(SICI)1096-987X(199604)17:5/6<587::AID-JCC4>3.0.CO;2-Q
[^7]:Halgren T A. Merck molecular force field. V. Extension of MMFF94 using experimental data, additional computational data, and empirical rules[J]. J. Comput. Chem., 1996, 17(5/6): 616-641. DOI:10.1002/(SICI)1096-987X(199604)17:5/6<616::AID-JCC5>3.0.CO;2-X

